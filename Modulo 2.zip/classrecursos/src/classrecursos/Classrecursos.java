/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classrecursos;

/**
 *
 * @author Keren Serrano
 */
public class Classrecursos {

  // Primer método: Retornar un mensaje
    public String obtenerMensaje() {
        return "Programación Orientada a Objetos 2021";
    }

    // Segundo método: Evaluar si la edad es mayor o menor de edad
    public String evaluarEdad(int edad) {
        if (edad >= 21) {
            return "Mayor de edad";
        } else {
            return "Menor de edad";
        }
    }

    // Tercer método: Multiplicación de dos enteros
    public int multiplicar(int a, int b) {
        return a * b;
    }

    // Cuarto método: Retornar una lista de números del 1 al X
    public int[] generarListaNumeros(int x) {
        int[] lista = new int[x];
        for (int i = 0; i < x; i++) {
            lista[i] = i + 1;
        }
        return lista;
    }
}