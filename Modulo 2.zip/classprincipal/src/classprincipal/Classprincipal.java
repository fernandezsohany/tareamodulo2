/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classprincipal;

/**
 *
 * @author Keren Serrano
 */
public class Classprincipal {

   public static void main(String[] args) {
        // Crear una instancia de la clase Recursos
        Recursos recursos = new Recursos();
        
        // Llamar al primer método
        String mensaje = recursos.obtenerMensaje();
        System.out.println(mensaje);

        // Llamar al segundo método con una edad de ejemplo
        int edad = 20; // Puedes cambiar este valor para probar diferentes edades
        String resultadoEdad = recursos.evaluarEdad(edad);
        System.out.println("La persona con edad " + edad + " es: " + resultadoEdad);

        // Llamar al tercer método con dos números de ejemplo
        int num1 = 4;
        int num2 = 5;
        int resultadoMultiplicacion = recursos.multiplicar(num1, num2);
        System.out.println("La multiplicación de " + num1 + " y " + num2 + " es: " + resultadoMultiplicacion);

        // Llamar al cuarto método con un valor de ejemplo
        int x = 10; // Puedes cambiar este valor para probar diferentes tamaños de lista
        int[] listaNumeros = recursos.generarListaNumeros(x);
        System.out.print("Lista de números del 1 al " + x + ": ");
        for (int numero : listaNumeros) {
            System.out.print(numero + " ");
        }
        System.out.println();
    }
}